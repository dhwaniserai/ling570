#!/bin/sh
output=$1
/opt/python-3.6/bin/python3 ./hmm_2gram.py $output