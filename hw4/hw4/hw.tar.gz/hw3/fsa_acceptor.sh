#!/bin/sh

fsa=$1
input=$2

cat $input | while read line
do
	ans=`echo "$line" | carmel -sli $fsa`
	if [ "$ans" = "" ];
	then
		echo -e "$line\t=>\tno"
	else
		echo -e "$line\t=>\tyes"
	fi

done
