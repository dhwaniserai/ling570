import sys
import re
fsa_path = sys.argv[1]
#print(fsa_path)
ex_path = sys.argv[2]
#print(ex_path)
fsa = {}
with open(fsa_path,"r") as f:
	fsa_text = f.read().strip()
	#print("fsa text", fsa_text)
	fsa_lines=fsa_text.split('\n')
	fsa["accept_state"] = fsa_lines[0]
	fsa["start_state"] = fsa_lines[1][1]
	fsa["productions"] = fsa_lines[1:]
	fsa["states"] = list(set([fsa_text[i+1] for i,val in enumerate(fsa_text) if val=='('])) #after every round bracket there is a non-terminal
	f.close()
for i in range(len(fsa['productions'])):
	#fsa['productions'][i] = fsa['productions'][i][:-2].split('(')
	fsa['productions'][i]=fsa['productions'][i].replace('(','')
	fsa['productions'][i]=fsa['productions'][i].replace(')','')
	fsa['productions'][i]=fsa['productions'][i].replace('"','')
	fsa['productions'][i]=fsa['productions'][i].split()
print("Prods", fsa['productions'])
examples,example_chars = '',{}
with open(ex_path,"r") as f:
	#print("og ex", f.read())
	og = f.read().strip()
	og = og.replace('"','')
	example_chars = set(og.split())
	examples = og.split('\n')
	for i in range(0,len(examples)):
		examples[i] = examples[i].replace('"','')
	f.close()
#print("eg", examples)
#print("ex chars",example_chars)
transition_table = {state: {inp:0 for inp in example_chars} for state in fsa["states"]}
#print("Trans table",transition_table)
for prod in fsa['productions']: #prod: State s1 => State s2 on input i
	transition_table[prod[0]][prod[2]]= prod[1]
	#transition_table[state_initial][str_input]=state_new
print("Trans table",transition_table)

## dfa parsing
for inp_string in examples:
	inp = inp_string.split()
	curr_state = fsa["start_state"]
	i=0
	while i < len(inp):
		if i==len(inp)-1:
			if curr_state == fsa["accept_state"] and transition_table[curr_state][inp[i]] != 0:
				print('"' + '"'.join(inp_string) + '" => yes')
				i=len(inp) #end loop
			else: 
				print('"' + '"'.join(inp_string) + '" => no')
				i=len(inp)
		elif transition_table[curr_state][inp[i]] == 0:
			print('"' + '"'.join(inp_string) + '" => no')
			i=len(inp)
		else:
			curr_state = transition_table[curr_state][inp[i]]
			i = i + 1
