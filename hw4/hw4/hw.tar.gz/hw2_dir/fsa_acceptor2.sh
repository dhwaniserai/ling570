#!/bin/sh
/opt/python-3.6/bin/python3 ./fsa_acceptor2.py $1 $2
