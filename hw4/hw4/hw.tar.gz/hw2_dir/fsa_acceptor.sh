#!/bin/sh
while read -r line
do
	if echo "$line" | carmel -sli $1 | grep -q "0"
	then
		echo "$line => yes"
	else
		echo "$line => no"
	fi
done < "$2"
