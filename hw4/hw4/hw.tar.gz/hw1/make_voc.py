#take standard input, read line by line split each line for each 
#whitespace, keep track of frequency of tokens and dump it to the 
#output file

#Output format
#token(tab)	frequency

#!/usr/bin/python

"""%prog [--help] [N]

This script prints the first N lines from STDIN.  If N is not specified, STDIN
is printed until exhausted."""

import sys


def n_lines_from_stdin(n):
	"""Return the first n lines from STDIN """
	text = ""
	while n:
		line = sys.stdin.readline()
		if not line:
			break
		text=text+" "+line.rstrip()
		n -= 1
	return text

if __name__ == "__main__":
	from optparse import OptionParser
	parser = OptionParser(__doc__)
	options, args = parser.parse_args()
	if len(args) == 0:
		n = -1
	else:
		n = int(args[0])
	text = n_lines_from_stdin(n)


	tokens = text.split()
	freq={}
	for t in tokens:
		if t in freq:
			freq[t] += 1
		else:
			freq[t] = 1
	for word in freq:
		print(word + "\t" + str(freq[word]))
