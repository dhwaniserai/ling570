#!/bin/sh
/opt/python-3.6/bin/python3 ./make_voc.py
