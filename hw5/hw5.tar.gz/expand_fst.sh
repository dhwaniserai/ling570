#!/bin/sh
/opt/python-3.6/bin/python3 ./expand_fst.py $1 $2 $3