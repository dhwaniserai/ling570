#!/bin/sh
/opt/python-3.6/bin/python3 ./reg_to_fsa.py
