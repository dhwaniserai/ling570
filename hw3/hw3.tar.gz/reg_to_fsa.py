import sys
import nltk
input_file = ""
text = ""
#with open(input_file,"r") as f:
#    text = f.read()
#    text=text.strip()

#account for 3 types of right grammar productions
class Grammar:
    def __init__(self):
        self.text=""
        self.final = "_F_"
        self.final_states=[]
        self.carmel_format = []
    def convert_type1(self,prod):
        #type1 prods A t B where t is a terminal and B is a non-terminal
        elements = prod.split()
        c_prod = ""
        if elements[1] == "*e*":
            c_prod ='('+elements[0]+' '+'('+elements[2]+' *e*))' 

        else:
            c_prod='('+elements[0]+' '+'('+elements[2]+' \"'+elements[1]+'\"))'
        
        if c_prod not in self.carmel_format:
            self.carmel_format.append(c_prod)

        if elements[0] in self.final_states:
            index = self.final_states.index(elements[0])
            self.final_states[index] = elements[2]
        else:
            self.final_states.append(elements[2])

    def convert_type2(self,prod): #A => terminal i.e. A t
        elements = prod.split()
        if elements[1] == "*e*":
            c_prod='('+elements[0]+' '+'('+self.final+' *e*))'

        else:
            c_prod ='('+elements[0]+' '+'('+self.final+' \"'+elements[1]+'\"))'
        
        if c_prod not in self.carmel_format:
            self.carmel_format.append(c_prod)

    def convert_other_finals_to_final(self):
        if len(self.final_states) != 0:
            for state in self.final_states:
                prod='('+state+' '+'('+self.final+' *e*))'
                if prod not in self.carmel_format:
                    self.carmel_format.append(prod)
    
    def print_output(self):
        print(self.final)
        for line in self.carmel_format:
            print(line)

if __name__ == "__main__":
    
    obj = Grammar()
    obj.text = sys.stdin.readlines()
    #with open(file_path,"r") as f:
    #    obj.text = f.read()
    #    obj.text=obj.text.strip()
    for line in obj.text:
        if len(line.split())==3:
            obj.convert_type1(line)

        elif len(line.split())==2:
            obj.convert_type2(line)
        else:
            print("Other line",line)
    obj.convert_other_finals_to_final()
    obj.print_output()        

